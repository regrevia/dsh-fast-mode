<p align="center">
  <picture>
    <source media="(prefers-color-scheme: dark)" srcset="https://raw.githubusercontent.com/regrevia/dsh-fast-mode/main/assets/logo-dark.png">
    <img src="https://raw.githubusercontent.com/regrevia/dsh-fast-mode/main/assets/logo.png" width="120" alt="dsh-fast-mode">
  </picture>
</p>

<h1 align="center">dsh-fast-mode</h1>

<p align="center">
  <b>DeepSeek Harness's own fast mode: the same model, half the output, up to twice as fast.</b><br>
  Several switches you combine freely, all prompt-side: no model swap, no lower reasoning effort, no request field written.<br>
  Best measured: <b>0.505x</b> wall clock, output tokens <b>−42%</b>, <b>438/438</b> checks green — <a href="BENCHMARK.md">benchmark and repro</a>.
</p>

<p align="center">
  <a href="https://github.com/regrevia/dsh-fast-mode/actions/workflows/ci.yml"><img alt="ci" src="https://github.com/regrevia/dsh-fast-mode/actions/workflows/ci.yml/badge.svg"></a>
  <a href="https://github.com/regrevia/dsh-fast-mode/releases"><img alt="release" src="https://img.shields.io/github/v/release/regrevia/dsh-fast-mode"></a>
  <img alt="deps" src="https://img.shields.io/badge/dependencies-1%20(schemastery)-blue">
  <img alt="license" src="https://img.shields.io/badge/license-MIT-blue">
  <a href="README.md">中文</a>
</p>

---

## At a glance

30 complete task pairs, same model, same settings, only three switches apart:

| Metric | Result |
|---|---|
| **Wall clock** | **0.505x** (about twice as fast; 26 of 30 pairs faster) |
| **Output tokens** | **−42%** (16037 → 9380) |
| **Reasoning characters** | **−51%** (42380 → 20872) |
| **Task quality** | **438/438** checks green, 30/30 runs passing |

All three switches plus the panel defaults is the fastest setting; the bolt alone, with the three newer switches off, is **0.823x** over the full 138-pair pool (18 % saved).

## Install

```bash
dsh plugin install dsh-fast-mode
```

Click the bolt in a conversation. Right-click it for the eight-row panel — every row affects that conversation only.

## What the eight buttons do

All eight are prompt-side: no request parameter, no model change, no change to completion checks. The first two shape output, the last one shapes how much context arrives, the five in between shape the route.

| Button | How it works | Default |
|---|---|---|
| **Concise output** | No call previews, no restating results, no progress reports; the final answer is not shortened | On |
| **Step cap** | A hard cap; at the limit it reports status instead of truncating the task | No cap |
| **File inventory** | Hands the model a directory listing up front, skipping the opening `ls`/`find` | Off |
| **Batched reads** | Independent reads go out as one batch, fewer round trips | Off |
| **Trim tool output** | Keeps head, tail and matching error lines instead of the whole output | Off |
| **Verify before guessing** | Read the uncertain fact once; not pure speed — it saves the retry a wrong guess costs | Off |
| **Act before explaining** | At most one line of plan; past 4000 characters of reasoning, a nudge to act on evidence | Off |
| **Nudge on repeats** | The same call again, or three identical results: one line saying to change the approach | Off |

The middle five arrived in 1.7.0 and ship **off**; the reasons are under Limits below. Trim tool output reached the panel in 1.7.12 — it is the one switch that changes the evidence the model sees, so it ships off, and off means the original text.

## Benchmark

All three on (`trio17`) vs all off, paired per task, 4000 bootstrap resamples:

| Block | Pairs | Wall clock (geometric) | 95 % CI | Faster |
|---|---|---|---|---|
| DP17 | 12 | 0.647x | [0.501, 0.893] | 10/12 |
| DP18 | 9 | 0.491x | [0.314, 0.788] | 8/9 |
| DP20b (shipped build) | 9 | 0.372x | [0.240, 0.563] | 8/9 |
| **Pooled** | **30** | **0.505x** | **[0.401, 0.635]** | **26/30** |

On the shipped build: steps 13.2 → 6.7, wall clock 464.9 s → 173.1 s. In every block, all-three-on is the only arm whose interval stays below 1. Raw data and recompute commands are in [BENCHMARK.md](BENCHMARK.md).

## Why it is faster, and where it is not

A step costs roughly round-trip overhead × steps + decode time × output tokens + tool wait. The model is not in that equation, so this only moves programmatic quantities: fewer round trips, fewer re-reads, fewer repeated edits.

- **Some tasks get slower — do not expect a win everywhere.** 1–5 step repairs and data reshaping do not repay the hint cost (`perfrefactor` 1.18x, `csvpipe` 1.12x); implementation-shaped tasks occasionally take one extra step (one 1.04x pair in DP20).
- **Quality first.** In every accepted batch both arms produced identical hidden assertions; safety checks, destructive operations and accessibility paths always run the full validation.
- **The switch is yours.** Only concise output is on by default; the three newer switches stay off because their payoff varies by task shape.

Recommendation: **most of the time, turn all three on.** If you want the safest single switch, take *Verify before guessing*; for long reasoning chains take *Act before explaining*; *Nudge on repeats* alone measured 1.007x and fired 3 times across twelve sessions — harmless in the combination, not worth switching alone.

## License

MIT. Reference: [docs/REFERENCE.en.md](docs/REFERENCE.en.md). Changes: [CHANGELOG.md](CHANGELOG.md).
