/**
 * Per-step measurement, so "does fast mode actually make it faster" can be
 * answered with numbers instead of a feeling.
 *
 * The harness already reports what this needs, one event at a time: `step/start`
 * opens a step, `assistant/chunk` marks the first streamed token (the real
 * time-to-first-token); `assistant/message` carries the upstream `usage`, `tool/call`
 * and `tool/result` count the work inside the step, `step/end` closes it. This
 * module folds that feed into one JSON line per step and appends it to a file.
 *
 * Why a file and not the session log: measurements are diagnostics, not
 * conversation. Appending to the session would put every timing into the
 * model's context and cost exactly the tokens the plugin exists to save.
 *
 * Both modes are recorded. A log that only covers sessions with fast mode on
 * cannot answer the comparison question, so the "off" rows are as important as
 * the "on" rows — the same task, measured on both sides.
 *
 * @module dsh-fast-mode/metrics
 */
import { appendFileSync, mkdirSync, renameSync, statSync } from 'node:fs'
import { dirname } from 'node:path'

import { trim } from './bounded.js'
import { findUsage, readUsage } from './usage.js'

/** The measurement format. Bumped when a field changes meaning. */
export const METRICS_VERSION = 2

/**
 * Ceilings for the four long-lived caches below. A host process lives for weeks
 * and these caches are keyed by ids that never repeat, so "one entry per session
 * it has ever seen" is an unbounded ceiling in disguise. The caps are far above
 * anything one process holds at a time (the harness runs a handful of sessions
 * and a few calls concurrently), so in practice they never evict a live entry —
 * they exist so a long uptime cannot turn into a heap that only a restart fixes.
 */
export const LABELS_MAX = 2000
/** In-flight step accumulators; one per open step across all sessions. */
export const STEPS_MAX = 2000
/** Which step a session's first streamed chunk belongs to. */
export const OPEN_MAX = 2000
/** A chunk that arrived before its `step/start`. */
export const PENDING_MAX = 1000

/**
 * The size at which the step journal is rotated to `<file>.1`.
 *
 * This is a diagnostic sink, not an archive: one JSON line per step means a
 * profile that stays installed for months grows it without bound (a real one
 * reached 7.6 MB in three weeks here). Past this size the current file is
 * renamed once and a fresh one is started, so the profile holds at most two
 * generations (~16 MB) and `report` still reads both. Rotation is best-effort:
 * a failure to rename must never cost the row being written.
 */
export const METRICS_ROTATE_BYTES = 8 * 1024 * 1024

/**
 * Runtime override for the rotation cap.
 *
 * Benchmarks read this journal by byte offset (size before minus after a run),
 * so a rotation in the middle of a measurement window would hide the rows the
 * run just wrote. A campaign sets this to a large value and rotates manually
 * between campaigns; users never need it.
 */
const rotationCap = () => {
  const raw = process.env.DSH_FAST_MODE_METRICS_MAX_BYTES
  const parsed = Number(raw)
  return Number.isFinite(parsed) && parsed > 0 ? parsed : METRICS_ROTATE_BYTES
}

/**
 * The step events this recorder folds. Anything else on the session feed
 * (`message/*`, `tool/*` wrappers, model selection) is irrelevant here.
 */
const STEP_START = 'step/start'
const STEP_END = 'step/end'
const ASSISTANT_CHUNK = 'assistant/chunk'
const ASSISTANT = 'assistant/message'
const TOOL_CALL = 'tool/call'
const TOOL_RESULT = 'tool/result'

/** @param {unknown} value */
const isTime = value => typeof value === 'number' && Number.isFinite(value) && value > 0

/**
 * The bucket key of one step of one session.
 *
 * @param {string} sid @param {unknown} turn @param {unknown} step
 */
const stepKey = (sid, turn, step) => `${sid}\u0000${String(turn)}\u0000${String(step)}`

/**
 * The payload of a session event.
 *
 * The feed wraps every payload in `event.data` (`step/start` appends
 * `{turn, step}`, `assistant/message` appends `{turn, step, message, usage?}`).
 * Reading `event.turn`/`event.usage` compiled and produced rows with no step
 * numbers and zero tokens for a whole release, so this unwrapping is the one
 * place that must not be guessed at again: `data` first, the event itself only
 * as a fallback for shapes that have no wrapper.
 *
 * @param {any} event
 */
/**
 * What kind of token opened the stream. A reasoning delta means the model started
 * thinking before it wrote anything, which is the common case on this route.
 *
 * @param {any} chunk
 */
const chunkKind = (chunk) => {
  if (!chunk || typeof chunk !== 'object') return 'unknown'
  return typeof chunk.type === 'string' ? chunk.type : 'unknown'
}

/**
 * The text a delta chunk carries. Adapters spell it `text` or `delta`; anything
 * else is counted as zero characters rather than guessed at, so the column can
 * be read as a lower bound and never as an estimate.
 *
 * @param {any} chunk
 */
const deltaText = (chunk) => {
  if (!chunk || typeof chunk !== 'object') return ''
  if (typeof chunk.text === 'string') return chunk.text
  if (typeof chunk.delta === 'string') return chunk.delta
  const nested = chunk.delta
  return nested && typeof nested === 'object' && typeof nested.text === 'string' ? nested.text : ''
}

const payloadOf = (event) => {
  const data = event && typeof event === 'object' ? event.data : undefined
  return data && typeof data === 'object' ? data : (event ?? {})
}

/**
 * Read one usage object in any of the dialects a route may speak.
 *
 * The spelling table lives in `usage.js`, because the scheduler budgets against
 * the same numbers. This module only needs the fold: a self-hosted gateway that
 * says `completion_tokens` must produce the same row as the official API.
 */

/**
 * Milliseconds between two event timestamps, never negative.
 *
 * @param {number} from @param {number} to
 */
const span = (from, to) => (isTime(from) && isTime(to) ? Math.max(0, Math.round(to - from)) : undefined)

/**
 * Create a recorder. Construction is cheap and never touches the disk: the file
 * is created lazily on the first completed step.
 *
 * @param {{file?: string}} [options]
 */
export function createRecorder(options = {}) {
  const file = typeof options.file === 'string' ? options.file : ''
  const on = file.length > 0
  /** @type {Map<string, any>} */
  const steps = new Map()
  /** @type {Map<string, {mode: string, gear: string, effort?: string, effortBase?: string, route?: string}>} */
  const labels = new Map()
  let prepared = false

  const prepare = () => {
    if (prepared || !on) return
    prepared = true
    try {
      mkdirSync(dirname(file), { recursive: true })
    } catch {
      // An unwritable directory disables the sink, not the request.
    }
  }

  // `assistant/chunk` is persisted with only the chunk — no turn, no step — so a
  // chunk cannot name its own step. One session runs one step at a time, so the
  // step that session last opened is the step the chunk belongs to.
  /** @type {Map<string, string>} */
  const open = new Map()
  /** @type {Map<string, {time: number, kind: string}>} */
  const pendingChunk = new Map()

  const write = (row) => {
    if (!on) return
    prepare()
    try {
      // One `stat` per completed step is far cheaper than an unbounded file, and
      // a missing file simply means "nothing to rotate yet".
      if (statSync(file).size >= rotationCap()) renameSync(file, `${file}.1`)
    } catch {
      // No file yet, or a directory we cannot write: the append below decides.
    }
    try {
      appendFileSync(file, `${JSON.stringify(row)}\n`)
    } catch {
      // A diagnostic sink must never break the request it observes.
    }
  }

  /** Get-or-open the accumulator for an event's step. */
  const accum = (sid, event, time) => {
    const key = stepKey(sid, event.turn, event.step)
    const found = steps.get(key)
    if (found) return { key, entry: found }
    const entry = {
      sid,
      turn: event.turn,
      step: event.step,
      started: time,
      first: undefined,
      last: undefined,
      chunkFirst: undefined,
      chunkKind: undefined,
      input: 0,
      output: 0,
      reasoning: 0,
      cacheRead: 0,
      cacheWrite: 0,
      calls: 0,
      errors: 0,
      seen: 0,
      reasoningChars: 0,
      textChars: 0,
    }
    steps.set(key, entry)
    trim(steps, STEPS_MAX)
    return { key, entry }
  }

  return {
    /** Whether anything will be written at all. */
    get enabled() { return on },

    /** The file this recorder appends to (empty when disabled). */
    get file() { return file },

    /**
     * Tell the next step rows which stance produced them. Called from the
     * request hook, which is the only place that knows the resolved gear.
     *
     * A call may carry only some fields: the omitted ones keep the session's
     * previous value, so a later call cannot blank the gear it does not know
     * about. `effortBase: null` is the one explicit clear, used when a step did
     * *not* step down — without it the previous reduction would be attributed to
     * every following row.
     *
     * @param {string|undefined} sid
     * @param {{mode?: string, gear?: string, effort?: string, effortBase?: string|null, route?: string}} label
     */
    label(sid, label) {
      if (typeof sid !== 'string' || sid.length === 0) return
      // With the sink off nothing will ever read this map, and the request hook
      // calls this for every session: remembering labels for a file that does
      // not exist is pure retention. (1.5.33 and earlier kept them anyway.)
      if (!on) return
      const previous = labels.get(sid)
      const next = {
        mode: label.mode !== undefined ? label.mode : previous && previous.mode,
        gear: label.gear !== undefined ? label.gear : previous && previous.gear,
        effort: label.effort !== undefined ? label.effort : previous && previous.effort,
        effortBase: label.effortBase === null
          ? undefined
          : label.effortBase !== undefined ? label.effortBase : previous && previous.effortBase,
        route: label.route !== undefined ? label.route : previous && previous.route,
      }
      if (previous && previous.mode === next.mode && previous.gear === next.gear
        && previous.effort === next.effort && previous.effortBase === next.effortBase
        && previous.route === next.route) return
      labels.set(sid, next)
      trim(labels, LABELS_MAX)
    },

    /** The last label recorded for a session. */
    labelOf(sid) {
      return labels.get(sid)
    },

    /**
     * Fold one session event.
     *
     * @param {{id?: string}} session
     * @param {{type?: string, time?: number, turn?: number, step?: number, usage?: unknown, error?: unknown}} event
     */
    record(session, event) {
      if (!on || !event || typeof event !== 'object') return
      const sid = session && typeof session.id === 'string' ? session.id : ''
      if (sid.length === 0) return
      const kind = event.type
      const time = isTime(event.time) ? event.time : Date.now()
      const data = payloadOf(event)

      if (kind === STEP_START) {
        const { key, entry } = accum(sid, data, time)
        entry.started = time
        steps.set(key, entry)
        open.set(sid, key)
        trim(steps, STEPS_MAX)
        trim(open, OPEN_MAX)
        const early = pendingChunk.get(sid)
        if (early) {
          entry.chunkFirst = early.time
          entry.chunkKind = early.kind
          pendingChunk.delete(sid)
        }
        return
      }

      // The first streamed chunk is the only honest time-to-first-token. The
      // `assistant/message` event is appended when the message is *committed*,
      // i.e. after the whole generation finished — measuring TTFT from it made
      // `ttftMs === llmMs` on every one of 2317 measured steps, which is how
      // this tap was found to be lying.
      if (kind === ASSISTANT_CHUNK) {
        // The durable feed appends the chunk alone — no turn, no step — so a chunk
        // cannot name its own step. One session runs one step at a time, so the
        // step that session last opened is the step the chunk belongs to.
        const chunkType = chunkKind(data.chunk)
        // `block-start`/`block-end` are framing markers, not tokens: counting one
        // as the first token would report a TTFT no text ever followed.
        if (!chunkType.endsWith('-delta')) return
        const key = open.get(sid)
        const entry = key === undefined ? undefined : steps.get(key)
        if (!entry) {
          // The live stream can arrive a few milliseconds before the durable
          // `step/start`; hold the first token until the step exists.
          if (!pendingChunk.has(sid)) {
            pendingChunk.set(sid, { time, kind: chunkType })
            trim(pendingChunk, PENDING_MAX)
          }
          return
        }
        // Streaming volume is the only live view of how much the model is
        // deliberating: this route reports zero reasoning *tokens* in `usage`
        // even when it streams a long reasoner block, so the character count is
        // the measurement that can actually be compared across arms.
        const carried = deltaText(data.chunk)
        if (chunkType === 'reasoning-delta') entry.reasoningChars += carried.length
        else if (chunkType === 'text-delta') entry.textChars += carried.length
        if (entry.chunkFirst === undefined) {
          entry.chunkFirst = time
          entry.chunkKind = chunkType
        }
        return
      }

      if (kind === ASSISTANT) {
        const { entry } = accum(sid, data, time)
        entry.seen += 1
        if (entry.first === undefined) entry.first = time
        entry.last = time
        // The message is appended with `usage` beside it; older adapters hang it
        // off the message instead, and a gateway may nest it under `response`.
        const tokens = readUsage(findUsage(data))
        entry.input += tokens.input
        entry.output += tokens.output
        entry.reasoning += tokens.reasoning
        entry.cacheRead += tokens.cacheRead
        entry.cacheWrite += tokens.cacheWrite
        return
      }

      if (kind === TOOL_CALL) {
        const { entry } = accum(sid, data, time)
        entry.calls += 1
        return
      }

      if (kind === TOOL_RESULT) {
        const { entry } = accum(sid, data, time)
        if (data.error) entry.errors += 1
        return
      }

      if (kind !== STEP_END) return

      const key = stepKey(sid, data.turn, data.step)
      const entry = steps.get(key)
      steps.delete(key)
      if (open.get(sid) === key) open.delete(sid)
      if (!entry) return
      const label = labels.get(sid)
      write({
        v: METRICS_VERSION,
        ts: new Date(time).toISOString(),
        sid,
        turn: entry.turn,
        step: entry.step,
        mode: label ? label.mode : 'unknown',
        gear: label ? label.gear : 'unknown',
        effort: label ? label.effort : undefined,
        effortBase: label ? label.effortBase : undefined,
        route: label ? label.route : undefined,
        // `ttftMs` is queue + prefill: `step/start` to the first streamed chunk.
        // `decodeMs` is the generation window that follows it. `llmMs` stays the
        // whole call, so old comparisons keep their meaning.
        ttftMs: entry.chunkFirst === undefined || span(entry.started, entry.chunkFirst) === undefined
          ? undefined
          : Math.max(0, span(entry.started, entry.chunkFirst)),
        decodeMs: entry.chunkFirst === undefined ? undefined : span(entry.chunkFirst, entry.last),
        firstChunk: entry.chunkKind,
        llmMs: entry.first === undefined ? undefined : span(entry.started, entry.last),
        stepMs: span(entry.started, time),
        calls: entry.calls,
        errors: entry.errors,
        input: entry.input,
        output: entry.output,
        reasoning: entry.reasoning,
        reasoningChars: entry.reasoningChars,
        textChars: entry.textChars,
        cacheRead: entry.cacheRead,
        cacheWrite: entry.cacheWrite,
        assistantMessages: entry.seen,
      })
    },

    /** Number of steps currently being accumulated (tests, diagnostics). */
    get pending() { return steps.size },
  }
}

/** @param {number[]} values @param {number} fraction */
function percentile(values, fraction) {
  if (values.length === 0) return undefined
  const sorted = [...values].sort((a, b) => a - b)
  const index = Math.min(sorted.length - 1, Math.max(0, Math.round(fraction * (sorted.length - 1))))
  return sorted[index]
}

/** @param {number[]} values */
const mean = (values) => (values.length === 0 ? undefined : Math.round(values.reduce((a, b) => a + b, 0) / values.length))

/**
 * Turn metric rows into one bucket per stance, which is what a comparison needs.
 *
 * Steps are the comparable unit: a session's wall clock also contains the user
 * reading and typing, so comparing whole sessions mostly measures the human.
 *
 * @param {any[]} rows
 */
export function summarise(rows) {
  /** @type {Map<string, any[]>} */
  const buckets = new Map()
  for (const row of Array.isArray(rows) ? rows : []) {
    if (!row || typeof row !== 'object') continue
    const key = `${row.mode ?? 'unknown'}|${row.gear ?? 'unknown'}`
    const list = buckets.get(key) ?? []
    list.push(row)
    buckets.set(key, list)
  }

  const out = []
  for (const [key, list] of buckets) {
    const [mode, gear] = key.split('|')
    const sessions = new Set(list.map(row => row.sid).filter(sid => typeof sid === 'string'))
    const turns = new Map()
    for (const row of list) {
      if (typeof row.sid !== 'string') continue
      const seen = turns.get(row.sid) ?? new Set()
      seen.add(row.turn)
      turns.set(row.sid, seen)
    }
    const turnCount = [...turns.values()].reduce((sum, seen) => sum + seen.size, 0)
    /** @param {(row: any) => number|undefined} pick */
    const numbers = (pick) => list.map(pick).filter(value => typeof value === 'number' && Number.isFinite(value))
    const llm = numbers(row => row.llmMs)
    const step = numbers(row => row.stepMs)
    const ttft = numbers(row => row.ttftMs)
    const decode = numbers(row => row.decodeMs)
    const output = numbers(row => row.output)
    const input = numbers(row => row.input)
    const calls = numbers(row => row.calls)
    out.push({
      mode,
      gear,
      steps: list.length,
      sessions: sessions.size,
      turns: turnCount,
      stepsPerTurn: turnCount === 0 ? undefined : Math.round((list.length / turnCount) * 100) / 100,
      llmMsP50: percentile(llm, 0.5),
      llmMsP90: percentile(llm, 0.9),
      llmMsMean: mean(llm),
      stepMsP50: percentile(step, 0.5),
      stepMsP90: percentile(step, 0.9),
      ttftMsP50: percentile(ttft, 0.5),
      ttftMsP90: percentile(ttft, 0.9),
      ttftMsMean: mean(ttft),
      decodeMsP50: percentile(decode, 0.5),
      // Queue + prefill as a share of the whole model call: the part a serving
      // tier could remove and decode cannot.
      prefillShare: (mean(ttft) === undefined || mean(llm) === undefined || mean(llm) === 0)
        ? undefined
        : Math.round((mean(ttft) / mean(llm)) * 1000) / 1000,
      outputPerStep: mean(output),
      inputPerStep: mean(input),
      outputPerSession: sessions.size === 0 ? undefined
        : Math.round(list.reduce((sum, row) => sum + (typeof row.output === 'number' ? row.output : 0), 0) / sessions.size),
      callsPerStep: calls.length === 0 ? undefined : Math.round((calls.reduce((a, b) => a + b, 0) / calls.length) * 100) / 100,
      multiCallSteps: list.filter(row => (row.calls ?? 0) > 1).length,
      errorCalls: list.reduce((sum, row) => sum + (typeof row.errors === 'number' ? row.errors : 0), 0),
    })
  }
  out.sort((a, b) => (a.mode === b.mode ? String(a.gear).localeCompare(String(b.gear)) : a.mode.localeCompare(b.mode)))
  return out
}

/**
 * Compare two stance buckets: how much of the wall clock fast mode removed.
 *
 * @param {any} baseline the `mode=off` bucket
 * @param {any} candidate an `mode=on` bucket at some gear
 */
export function compare(baseline, candidate) {
  if (!baseline || !candidate) return undefined
  const ratio = (a, b) => (typeof a === 'number' && typeof b === 'number' && b > 0
    ? Math.round((a / b) * 100) / 100
    : undefined)
  return {
    gear: candidate.gear,
    speedupLlm: ratio(baseline.llmMsMean, candidate.llmMsMean),
    speedupStep: ratio(baseline.stepMsP50, candidate.stepMsP50),
    outputRatio: ratio(candidate.outputPerStep, baseline.outputPerStep),
    tokensPerSessionRatio: ratio(candidate.outputPerSession, baseline.outputPerSession),
    callsRatio: ratio(candidate.callsPerStep, baseline.callsPerStep),
  }
}
